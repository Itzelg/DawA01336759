BULK INSERT A1336759.A1336759.[proyectos]
   FROM 'e:\wwwroot\A1336759\proyectos (1).csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )
