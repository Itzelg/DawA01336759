CREATE TABLE Materiales
(
  Clave numeric(5),
  Descripcion varchar(50),
  Costo numeric(8,2)
)

  CREATE TABLE Proveedores
(
  RFC CHAR (13),
  RazonSocial varchar(50),
)
  CREATE TABLE Proyectos
(
  numero numeric (5),
  denominacion varchar(50),
)

  CREATE TABLE entregan
(
  clave numeric (5),
  RFC char(13),
  numero numeric (5),
  fecha datetime,
  cantidad numeric(8,2),
)
