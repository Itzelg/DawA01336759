BULK INSERT A1336759.A1336759.[Proveedores]
   FROM 'e:\wwwroot\A1336759\proveedores.csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )
