
BULK INSERT A1336759.A1336759.[Materiales]
   FROM 'e:\wwwroot\A1336759\materiales (1).csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )
