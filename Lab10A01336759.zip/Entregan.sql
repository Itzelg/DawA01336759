SET DATEFORMAT dmy
BULK INSERT A1336759.A1336759.[entregan]
   FROM 'e:\wwwroot\A1336759\entregan (1).csv'
   WITH
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )
